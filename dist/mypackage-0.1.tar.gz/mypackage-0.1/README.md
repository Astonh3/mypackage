# my package 
This library was created as an example of how to publish your own Python Package

#How to Intsall
...